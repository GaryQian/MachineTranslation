Files:

	alignIBM1: Original implementation of IBM Model 1
	
	alignIBM1v2: Version 2 "cleaner" implementation of IBM Model 1
	
	aligndouble: Double f-e e-f implementation
	
	aligndoublediag: Double f-e e-f implementation with diagonal weighting
	
	aligndoublediagdice: Double f-e e-f implementation with diagonal weighting and dice coefficient initialization
	
	alignibm2: IBM Model 2 implementation with diagonal weighting
	
	alignibm2double: Double two-way f-e e-f IBM Model 2 implementation with diagonal weighting. Best performing algorithm.
	
These files are all python files and can be run with:

	$ python <filename>